#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define SIZE 100000000

int main() {
    int *data = malloc(SIZE * sizeof(int));
    // Datos aleatorios (-1 o 1)
    for (int i = 0; i < SIZE; i++) data[i] = (rand() % 2) * 2 - 1;

    clock_t start = clock();
    long sum = 0;
    for (int i = 0; i < SIZE; i++) {
        if (data[i] >= 0) { // Condición impredecible (50% true/false)
            sum += data[i];
        }
    }
    double time = (double)(clock() - start) / CLOCKS_PER_SEC;
    printf("C (impredecible): %.4f segundos\n", time);
    free(data);
    return 0;
}
