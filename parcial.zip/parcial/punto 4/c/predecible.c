#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define SIZE 100000000

int main() {
    int *data = malloc(SIZE * sizeof(int));
    // Datos ordenados (todos positivos)
    for (int i = 0; i < SIZE; i++) data[i] = i;

    clock_t start = clock();
    long sum = 0;
    for (int i = 0; i < SIZE; i++) {
        if (data[i] >= 0) { // Condición siempre verdadera (predecible)
            sum += data[i];
        }
    }
    double time = (double)(clock() - start) / CLOCKS_PER_SEC;
    printf("C (predecible): %.4f segundos\n", time);
    free(data);
    return 0;
}
