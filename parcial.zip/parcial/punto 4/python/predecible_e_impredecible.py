import time
import random

SIZE = 100000000

# Versión predecible (datos ordenados)
def predecible():
    data = [i for i in range(SIZE)]  # Todos positivos
    start = time.time()
    sum = 0
    for num in data:
        if num >= 0:  # Siempre True
            sum += num
    print(f"Python (predecible): {time.time() - start:.4f} segundos")

# Versión impredecible (datos aleatorios)
def impredecible():
    data = [random.choice([-1, 1]) for _ in range(SIZE)]  # 50% True/False
    start = time.time()
    sum = 0
    for num in data:
        if num >= 0:  # Aleatorio
            sum += num
    print(f"Python (impredecible): {time.time() - start:.4f} segundos")

predecible()
impredecible()
