# Punto 1: Analizador Léxico con AWK

## Descripción
Este programa en AWK procesa un archivo de texto (`token.txt`) y clasifica los tokens según las siguientes expresiones regulares:
- **REAL**: Números reales (ej: `3.14`).
- **ENTERO**: Números enteros (ej: `42`).
- **SUMA**: Símbolo `+`.
- **INCR**: Símbolo `++`.

## Archivos
- `token.awk`: Script en AWK que implementa el analizador léxico.
- `token.txt`: Archivo de entrada con los tokens a evaluar.

## Requisitos
- Tener instalado `gawk` (GNU AWK) en tu sistema.

### Instalación de AWK (Ubuntu/Debian)

sudo apt-get install gawk

Uso:

Ejecuta el script con el archivo token.txt como entrada:

gawk -f token.awk token.txt

NOTAS:
El programa ignora caracteres no reconocidos y continúa procesando el resto de la línea.
Asegúrate de que cada token esté en una línea separada en token.txt.
