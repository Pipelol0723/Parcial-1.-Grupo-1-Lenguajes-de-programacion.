#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
    if (argc != 3) return 1;
    FILE *file = fopen(argv[1], "r");
    if (!file) return 1;
    char *clave = argv[2];
    char palabra[100];
    int contador = 0;
    while (fscanf(file, "%99s", palabra) == 1) {
        if (strcmp(palabra, clave) == 0) contador++;
    }
    fclose(file);
    printf("%s se repite %d veces\n", clave, contador);
    return 0;
}
