import sys
from antlr4 import *
from ComplexLexer import ComplexLexer
from ComplexParser import ComplexParser
from CustomVisitor import ComplexVisitor

def main():
    input_stream = FileStream(sys.argv[1], encoding='utf-8')
    lexer = ComplexLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ComplexParser(stream)
    tree = parser.prog()
    visitor = CustomVisitor()
    result = visitor.visit(tree)
    print(f"Resultado: {result}")

if __name__ == '__main__':
    main()
