# Generated from Complex.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,10,51,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,1,0,4,0,12,8,0,
        11,0,12,0,13,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,1,27,
        8,1,10,1,12,1,30,9,1,1,2,1,2,1,2,1,2,1,2,3,2,37,8,2,1,3,1,3,1,3,
        1,3,1,3,1,3,1,3,1,4,3,4,47,8,4,1,4,1,4,1,4,0,1,2,5,0,2,4,6,8,0,3,
        1,0,4,5,1,0,2,3,1,0,8,9,50,0,11,1,0,0,0,2,17,1,0,0,0,4,36,1,0,0,
        0,6,38,1,0,0,0,8,46,1,0,0,0,10,12,3,2,1,0,11,10,1,0,0,0,12,13,1,
        0,0,0,13,11,1,0,0,0,13,14,1,0,0,0,14,15,1,0,0,0,15,16,5,0,0,1,16,
        1,1,0,0,0,17,18,6,1,-1,0,18,19,3,4,2,0,19,28,1,0,0,0,20,21,10,3,
        0,0,21,22,7,0,0,0,22,27,3,2,1,4,23,24,10,2,0,0,24,25,7,1,0,0,25,
        27,3,2,1,3,26,20,1,0,0,0,26,23,1,0,0,0,27,30,1,0,0,0,28,26,1,0,0,
        0,28,29,1,0,0,0,29,3,1,0,0,0,30,28,1,0,0,0,31,37,3,6,3,0,32,33,5,
        6,0,0,33,34,3,2,1,0,34,35,5,7,0,0,35,37,1,0,0,0,36,31,1,0,0,0,36,
        32,1,0,0,0,37,5,1,0,0,0,38,39,5,6,0,0,39,40,3,8,4,0,40,41,7,1,0,
        0,41,42,3,8,4,0,42,43,5,1,0,0,43,44,5,7,0,0,44,7,1,0,0,0,45,47,7,
        1,0,0,46,45,1,0,0,0,46,47,1,0,0,0,47,48,1,0,0,0,48,49,7,2,0,0,49,
        9,1,0,0,0,5,13,26,28,36,46
    ]

class ComplexParser ( Parser ):

    grammarFileName = "Complex.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'i'", "'+'", "'-'", "'*'", "'/'", "'('", 
                     "')'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "ADD", "SUB", "MUL", "DIV", 
                      "LPAREN", "RPAREN", "INT", "FLOAT", "WS" ]

    RULE_prog = 0
    RULE_expr = 1
    RULE_atom = 2
    RULE_complex = 3
    RULE_number = 4

    ruleNames =  [ "prog", "expr", "atom", "complex", "number" ]

    EOF = Token.EOF
    T__0=1
    ADD=2
    SUB=3
    MUL=4
    DIV=5
    LPAREN=6
    RPAREN=7
    INT=8
    FLOAT=9
    WS=10

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(ComplexParser.EOF, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ComplexParser.ExprContext)
            else:
                return self.getTypedRuleContext(ComplexParser.ExprContext,i)


        def getRuleIndex(self):
            return ComplexParser.RULE_prog

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProg" ):
                listener.enterProg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProg" ):
                listener.exitProg(self)




    def prog(self):

        localctx = ComplexParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 11 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 10
                self.expr(0)
                self.state = 13 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==6):
                    break

            self.state = 15
            self.match(ComplexParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom(self):
            return self.getTypedRuleContext(ComplexParser.AtomContext,0)


        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ComplexParser.ExprContext)
            else:
                return self.getTypedRuleContext(ComplexParser.ExprContext,i)


        def MUL(self):
            return self.getToken(ComplexParser.MUL, 0)

        def DIV(self):
            return self.getToken(ComplexParser.DIV, 0)

        def ADD(self):
            return self.getToken(ComplexParser.ADD, 0)

        def SUB(self):
            return self.getToken(ComplexParser.SUB, 0)

        def getRuleIndex(self):
            return ComplexParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = ComplexParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 18
            self.atom()
            self._ctx.stop = self._input.LT(-1)
            self.state = 28
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 26
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                    if la_ == 1:
                        localctx = ComplexParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 20
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 21
                        _la = self._input.LA(1)
                        if not(_la==4 or _la==5):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 22
                        self.expr(4)
                        pass

                    elif la_ == 2:
                        localctx = ComplexParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 23
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 24
                        _la = self._input.LA(1)
                        if not(_la==2 or _la==3):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 25
                        self.expr(3)
                        pass

             
                self.state = 30
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def complex_(self):
            return self.getTypedRuleContext(ComplexParser.ComplexContext,0)


        def LPAREN(self):
            return self.getToken(ComplexParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(ComplexParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(ComplexParser.RPAREN, 0)

        def getRuleIndex(self):
            return ComplexParser.RULE_atom

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom" ):
                listener.enterAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom" ):
                listener.exitAtom(self)




    def atom(self):

        localctx = ComplexParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_atom)
        try:
            self.state = 36
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 31
                self.complex_()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 32
                self.match(ComplexParser.LPAREN)
                self.state = 33
                self.expr(0)
                self.state = 34
                self.match(ComplexParser.RPAREN)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComplexContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.real = None # NumberContext
            self.sign = None # Token
            self.imag = None # NumberContext

        def LPAREN(self):
            return self.getToken(ComplexParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(ComplexParser.RPAREN, 0)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ComplexParser.NumberContext)
            else:
                return self.getTypedRuleContext(ComplexParser.NumberContext,i)


        def ADD(self):
            return self.getToken(ComplexParser.ADD, 0)

        def SUB(self):
            return self.getToken(ComplexParser.SUB, 0)

        def getRuleIndex(self):
            return ComplexParser.RULE_complex

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplex" ):
                listener.enterComplex(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplex" ):
                listener.exitComplex(self)




    def complex_(self):

        localctx = ComplexParser.ComplexContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_complex)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 38
            self.match(ComplexParser.LPAREN)
            self.state = 39
            localctx.real = self.number()
            self.state = 40
            localctx.sign = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==2 or _la==3):
                localctx.sign = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 41
            localctx.imag = self.number()
            self.state = 42
            self.match(ComplexParser.T__0)
            self.state = 43
            self.match(ComplexParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(ComplexParser.INT, 0)

        def FLOAT(self):
            return self.getToken(ComplexParser.FLOAT, 0)

        def ADD(self):
            return self.getToken(ComplexParser.ADD, 0)

        def SUB(self):
            return self.getToken(ComplexParser.SUB, 0)

        def getRuleIndex(self):
            return ComplexParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = ComplexParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 46
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2 or _la==3:
                self.state = 45
                _la = self._input.LA(1)
                if not(_la==2 or _la==3):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 48
            _la = self._input.LA(1)
            if not(_la==8 or _la==9):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         




