from antlr4 import *
from ComplexLexer import ComplexLexer
from ComplexParser import ComplexParser
from ComplexVisitor import ComplexVisitor

class ComplexNumber:
    def __init__(self, real, imag):
        self.real = real
        self.imag = imag
    def __add__(self, other):
        return ComplexNumber(self.real + other.real, self.imag + other.imag)
    def __sub__(self, other):
        return ComplexNumber(self.real - other.real, self.imag - other.imag)
    def __mul__(self, other):
        return ComplexNumber(
            self.real * other.real - self.imag * other.imag,
            self.real * other.imag + self.imag * other.real
        )
    def __truediv__(self, other):
        denom = other.real**2 + other.imag**2
        return ComplexNumber(
            (self.real * other.real + self.imag * other.imag) / denom,
            (self.imag * other.real - self.real * other.imag) / denom
        )
    def __str__(self):
        return f"{self.real} + {self.imag}i"

class CustomVisitor(ComplexVisitor):
    def visitComplexAtom(self, ctx):
        real = float(ctx.number()[0].getText())
        imag = float(ctx.number()[1].getText())
        if ctx.sign.text == '-': imag = -imag
        return ComplexNumber(real, imag)
    def visitMulDiv(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        return left * right if ctx.op.type == ComplexParser.MUL else left / right
    def visitAddSub(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        return left + right if ctx.op.type == ComplexParser.ADD else left - right
    def visitParensAtom(self, ctx):
        return self.visit(ctx.expr())
    def visitAtomExpr(self, ctx):
        return self.visit(ctx.atom())
