# Punto 2: Validador de Expresiones Lambda en Python con LEX

## Descripción
Este programa valida expresiones lambda de Python utilizando un analizador léxico implementado en LEX. Evalúa si la sintaxis de una expresión lambda es correcta y devuelve `ACEPTA` o `NO ACEPTA`.

## Archivos
- `lambda.l`: Archivo LEX con las reglas léxicas para validar expresiones lambda.
- `lex.yy.c`: Código C generado por LEX (no editar manualmente).
- `lambda`: Ejecutable compilado a partir de `lex.yy.c`.
- `archivo.txt`: Ejemplo de entrada **válida**.
- `archivo_no_acepta.txt`: Ejemplo de entrada **inválida**.

## Requisitos
- **Flex**: Generador de analizadores léxicos.
- **GCC**: Compilador de C.

### Instalación de dependencias (Ubuntu/Debian)
```bash
sudo apt-get install flex gcc
Notas

    El programa valida solo la sintaxis lambda, no ejecuta código.

    Caracteres no reconocidos (ej: @, $) causan rechazo inmediato.

    Los paréntesis deben estar balanceados para ser aceptados.
